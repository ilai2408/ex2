/******************
Name:
ID:
Assignment:
*******************/

#include <stdio.h>

int main()
{
    // MAIN MENU LOOP

    // TASK 1: Ducky's Unity Game

    // TASK 2: The Memory Game

    // TASK 3: Professor Pat's Power Calculation

    // TASK 4: The Duck Parade

    // TASK 5: The Mystery of the Repeated Digits

    // TASK 6: EXIT

    // dont forget through all the necessary parts to validate invalid input.

    return 0;
}
